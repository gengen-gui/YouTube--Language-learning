"use strict";
(() => {
  // src/inject.ts
  var lastVideoId = "";
  var liveMode = false;
  function post(msg) {
    window.postMessage({ source: "ytlingo-inject", ...msg }, "*");
  }
  function currentPlayerResponse() {
    const w = window;
    try {
      const player = document.querySelector("#movie_player");
      if (player && typeof player.getPlayerResponse === "function") {
        const pr = player.getPlayerResponse();
        if (pr?.videoDetails) return pr;
      }
    } catch {
    }
    return w.ytInitialPlayerResponse || null;
  }
  function hasCaptions(pr) {
    const tracks = pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
    return Array.isArray(tracks) && tracks.length > 0;
  }
  function findTranscriptParams(obj) {
    if (!obj || typeof obj !== "object") return null;
    if (obj.getTranscriptEndpoint?.params) return obj.getTranscriptEndpoint.params;
    for (const k in obj) {
      const r = findTranscriptParams(obj[k]);
      if (r) return r;
    }
    return null;
  }
  function collectSegments(obj, out) {
    if (!obj || typeof obj !== "object") return;
    if (obj.transcriptSegmentRenderer) {
      const s = obj.transcriptSegmentRenderer;
      const text = (s.snippet?.runs || []).map((r) => r.text || "").join("").replace(/\s+/g, " ").trim();
      const start = Number(s.startMs || 0) / 1e3;
      const end = Number(s.endMs || 0) / 1e3;
      if (text) out.push({ start, end, text });
      return;
    }
    for (const k in obj) collectSegments(obj[k], out);
  }
  async function fetchTranscript() {
    const w = window;
    const params = findTranscriptParams(w.ytInitialData);
    const key = w.ytcfg?.get?.("INNERTUBE_API_KEY");
    const context = w.ytcfg?.get?.("INNERTUBE_CONTEXT");
    if (!params || !key || !context) return null;
    try {
      const resp = await fetch(`/youtubei/v1/get_transcript?key=${key}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ context, params })
      });
      if (!resp.ok) return null;
      const json = await resp.json();
      const cues = [];
      collectSegments(json, cues);
      for (let i = 0; i < cues.length; i++) {
        if (!cues[i].end || cues[i].end <= cues[i].start) {
          cues[i].end = cues[i + 1] ? cues[i + 1].start : cues[i].start + 4;
        }
      }
      return cues.length ? cues : null;
    } catch {
      return null;
    }
  }
  function enableCaptions() {
    try {
      const player = document.querySelector("#movie_player");
      if (!player) return;
      if (typeof player.loadModule === "function") player.loadModule("captions");
      if (typeof player.getOption === "function" && typeof player.setOption === "function") {
        const tracklist = player.getOption("captions", "tracklist") || [];
        if (tracklist.length) {
          const track = tracklist.find((t) => (t.languageCode || "").startsWith("en")) || tracklist[0];
          player.setOption("captions", "track", track);
        }
      }
    } catch {
    }
  }
  async function scan(force = false) {
    const pr = currentPlayerResponse();
    if (!pr) return;
    const videoId = pr?.videoDetails?.videoId;
    const title = pr?.videoDetails?.title;
    if (!videoId) return;
    if (!force && videoId === lastVideoId) return;
    if (!hasCaptions(pr)) {
      lastVideoId = videoId;
      post({ type: "NO_CAPTIONS", videoId, title });
      return;
    }
    const cues = await fetchTranscript();
    if (cues && cues.length) {
      lastVideoId = videoId;
      post({ type: "CUES", videoId, title, cues });
      return;
    }
    lastVideoId = videoId;
    liveMode = true;
    enableCaptions();
    post({ type: "LIVE", videoId, title });
  }
  void scan(true);
  var ticks = 0;
  var poll = setInterval(() => {
    void scan();
    if (liveMode) enableCaptions();
    if (++ticks > 40) clearInterval(poll);
  }, 500);
  window.addEventListener("yt-navigate-finish", () => {
    lastVideoId = "";
    liveMode = false;
    setTimeout(() => void scan(true), 500);
  });
  window.addEventListener("message", (e) => {
    if (e.source === window && e.data?.source === "ytlingo-content" && e.data.type === "REQUEST") {
      void scan(true);
    }
  });
})();

"use strict";
(() => {
  // src/api.ts
  var DEFAULTS = {
    token: null,
    email: null,
    apiBase: "http://localhost:8787",
    targetLang: "zh-CN"
  };
  async function getSettings() {
    const stored = await chrome.storage.local.get(Object.keys(DEFAULTS));
    return { ...DEFAULTS, ...stored };
  }
  async function setSettings(patch) {
    await chrome.storage.local.set(patch);
  }
  async function api(path, init = {}) {
    const { apiBase, token } = await getSettings();
    const headers = {
      "Content-Type": "application/json",
      ...init.headers
    };
    if (token) headers.Authorization = `Bearer ${token}`;
    const resp = await fetch(`${apiBase}${path}`, { ...init, headers });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);
    return data;
  }
  var Api = {
    register: (email, password) => api("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({ email, password })
    }),
    login: (email, password) => api("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password })
    }),
    translatePreview: (text, targetLang) => api("/api/translate", {
      method: "POST",
      body: JSON.stringify({ text, targetLang })
    }),
    addVocab: (payload) => api("/api/vocab", { method: "POST", body: JSON.stringify(payload) }),
    listVocab: (videoId) => api(`/api/vocab${videoId ? `?videoId=${encodeURIComponent(videoId)}` : ""}`)
  };

  // src/popup.ts
  var $ = (id) => document.getElementById(id);
  var emailEl = $("email");
  var passwordEl = $("password");
  var apiBaseEl = $("apiBase");
  var targetLangEl = $("targetLang");
  var msgEl = $("msg");
  function showMsg(text, kind = "") {
    msgEl.textContent = text;
    msgEl.className = `msg ${kind}`;
  }
  async function refresh() {
    const s = await getSettings();
    apiBaseEl.value = s.apiBase;
    targetLangEl.value = s.targetLang;
    if (s.token) {
      $("loggedOut").classList.add("hidden");
      $("loggedIn").classList.remove("hidden");
      $("whoami").textContent = s.email || "";
    } else {
      $("loggedOut").classList.remove("hidden");
      $("loggedIn").classList.add("hidden");
    }
  }
  async function persistApiBase() {
    const val = apiBaseEl.value.trim().replace(/\/$/, "");
    if (val) await setSettings({ apiBase: val });
  }
  async function doAuth(mode) {
    await persistApiBase();
    const email = emailEl.value.trim();
    const password = passwordEl.value;
    if (!email || !password) return showMsg("Enter email and password", "err");
    showMsg("Please wait...");
    try {
      const res = mode === "login" ? await Api.login(email, password) : await Api.register(email, password);
      await setSettings({ token: res.token, email: res.user.email });
      showMsg(mode === "login" ? "Logged in!" : "Account created!", "ok");
      await refresh();
    } catch (err) {
      showMsg(err.message, "err");
    }
  }
  $("loginBtn").onclick = () => doAuth("login");
  $("registerBtn").onclick = () => doAuth("register");
  $("logoutBtn").onclick = async () => {
    await setSettings({ token: null, email: null });
    showMsg("Logged out", "ok");
    await refresh();
  };
  targetLangEl.onchange = () => setSettings({ targetLang: targetLangEl.value });
  apiBaseEl.onchange = persistApiBase;
  void refresh();
})();

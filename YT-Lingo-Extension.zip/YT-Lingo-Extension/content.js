"use strict";
(() => {
  // src/api.ts
  var DEFAULTS = {
    token: null,
    email: null,
    apiBase: "http://localhost:8787",
    targetLang: "zh-CN"
  };
  async function getSettings() {
    const stored = await chrome.storage.local.get(Object.keys(DEFAULTS));
    return { ...DEFAULTS, ...stored };
  }
  function onSettingsChanged(cb) {
    chrome.storage.onChanged.addListener(async (_changes, area) => {
      if (area === "local") cb(await getSettings());
    });
  }
  async function api(path, init = {}) {
    const { apiBase, token } = await getSettings();
    const headers = {
      "Content-Type": "application/json",
      ...init.headers
    };
    if (token) headers.Authorization = `Bearer ${token}`;
    const resp = await fetch(`${apiBase}${path}`, { ...init, headers });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);
    return data;
  }
  var Api = {
    register: (email, password) => api("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({ email, password })
    }),
    login: (email, password) => api("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password })
    }),
    translatePreview: (text, targetLang) => api("/api/translate", {
      method: "POST",
      body: JSON.stringify({ text, targetLang })
    }),
    addVocab: (payload) => api("/api/vocab", { method: "POST", body: JSON.stringify(payload) }),
    listVocab: (videoId) => api(`/api/vocab${videoId ? `?videoId=${encodeURIComponent(videoId)}` : ""}`)
  };

  // src/content.ts
  var currentVideoId = null;
  var currentTitle = "";
  var cues = [];
  var settings;
  var activeIndex = -1;
  var syncTimer = null;
  var selected = /* @__PURE__ */ new Set();
  function injectPageScript() {
    const s = document.createElement("script");
    s.src = chrome.runtime.getURL("inject.js");
    s.onload = () => s.remove();
    (document.head || document.documentElement).appendChild(s);
  }
  function requestScan() {
    window.postMessage({ source: "ytlingo-content", type: "REQUEST" }, "*");
  }
  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== void 0) node.textContent = text;
    return node;
  }
  var panel = null;
  var listEl = null;
  var statusEl = null;
  var toolbarEl = null;
  var toolbarCountEl = null;
  var selBtn = null;
  function ensurePanel() {
    if (panel && document.body.contains(panel)) return;
    panel = el("div", "ytlingo-panel");
    const header = el("div", "ytlingo-header");
    header.appendChild(el("span", "ytlingo-title", "YT Lingo"));
    const collapseBtn = el("button", "ytlingo-collapse", "\u2014");
    collapseBtn.title = "Collapse";
    collapseBtn.onclick = () => panel.classList.toggle("ytlingo-collapsed");
    header.appendChild(collapseBtn);
    panel.appendChild(header);
    statusEl = el("div", "ytlingo-status");
    panel.appendChild(statusEl);
    toolbarEl = el("div", "ytlingo-toolbar");
    toolbarCountEl = el("span", "ytlingo-tb-count", "");
    const saveSelBtn = el("button", "ytlingo-mini ytlingo-save", "\u2605 \u6536\u85CF\u9009\u4E2D");
    saveSelBtn.onclick = () => void saveSelectedCues();
    const clearBtn = el("button", "ytlingo-mini", "\u6E05\u9664");
    clearBtn.onclick = clearSelection;
    toolbarEl.appendChild(toolbarCountEl);
    toolbarEl.appendChild(saveSelBtn);
    toolbarEl.appendChild(clearBtn);
    panel.appendChild(toolbarEl);
    listEl = el("div", "ytlingo-list");
    panel.appendChild(listEl);
    listEl.addEventListener("mouseup", onTextSelected);
    selBtn = el("button", "ytlingo-selbtn", "\u2605 \u6536\u85CF\u6240\u9009");
    selBtn.style.display = "none";
    panel.appendChild(selBtn);
    document.body.appendChild(panel);
    updateToolbar();
  }
  function getVideoEl() {
    return document.querySelector("video.html5-main-video");
  }
  function setStatus(msg, kind = "info") {
    if (!statusEl) return;
    statusEl.textContent = msg;
    statusEl.className = `ytlingo-status ytlingo-${kind}`;
  }
  function makeCueRow(cue, i) {
    const row = el("div", "ytlingo-cue");
    row.dataset.index = String(i);
    const top = el("div", "ytlingo-cue-top");
    const check = el("input", "ytlingo-check");
    check.type = "checkbox";
    check.checked = selected.has(i);
    check.onclick = (e) => {
      e.stopPropagation();
      if (check.checked) selected.add(i);
      else selected.delete(i);
      updateToolbar();
    };
    top.appendChild(check);
    const textEl = el("div", "ytlingo-cue-text", cue.text);
    top.appendChild(textEl);
    row.appendChild(top);
    const actions = el("div", "ytlingo-actions");
    const jumpBtn = el("button", "ytlingo-mini", "\u25B6 Play");
    jumpBtn.onclick = (e) => {
      e.stopPropagation();
      const v = getVideoEl();
      if (v) {
        v.currentTime = cue.start;
        v.play().catch(() => {
        });
      }
    };
    const saveBtn = el("button", "ytlingo-mini ytlingo-save", "\u2605 Save");
    saveBtn.onclick = (e) => {
      e.stopPropagation();
      void saveCue(cue.text, cue.start, saveBtn, actions);
    };
    actions.appendChild(jumpBtn);
    actions.appendChild(saveBtn);
    row.appendChild(actions);
    textEl.onclick = () => row.classList.toggle("ytlingo-expanded");
    return row;
  }
  function renderCues() {
    if (!listEl) return;
    listEl.innerHTML = "";
    cues.forEach((cue, i) => listEl.appendChild(makeCueRow(cue, i)));
  }
  async function postVocab(text, startTime) {
    const { item } = await Api.addVocab({
      text,
      targetLang: settings.targetLang,
      videoId: currentVideoId || void 0,
      videoTitle: currentTitle || void 0,
      startTime
    });
    return item.translation || "";
  }
  async function saveCue(text, startTime, btn, actions) {
    if (!settings.token) {
      setStatus("\u8BF7\u5148\u5728\u6269\u5C55\u5F39\u7A97\u91CC\u767B\u5F55", "err");
      return;
    }
    btn.disabled = true;
    btn.textContent = "Saving...";
    try {
      const translation = await postVocab(text, startTime);
      btn.textContent = "\u2713 Saved";
      btn.classList.add("ytlingo-saved");
      if (translation) {
        let tr = actions.parentElement.querySelector(".ytlingo-translation");
        if (!tr) {
          tr = el("div", "ytlingo-translation");
          actions.parentElement.insertBefore(tr, actions);
        }
        tr.textContent = translation;
      }
    } catch (err) {
      btn.disabled = false;
      btn.textContent = "\u2605 Save";
      setStatus(err.message || "Save failed", "err");
    }
  }
  function updateToolbar() {
    if (!toolbarEl || !toolbarCountEl) return;
    const n = selected.size;
    toolbarEl.classList.toggle("ytlingo-show", n > 0);
    toolbarCountEl.textContent = `\u5DF2\u9009 ${n} \u53E5`;
  }
  function clearSelection() {
    selected.clear();
    if (listEl) {
      listEl.querySelectorAll("input.ytlingo-check").forEach((c) => {
        c.checked = false;
      });
    }
    updateToolbar();
  }
  async function saveSelectedCues() {
    if (!settings.token) {
      setStatus("\u8BF7\u5148\u5728\u6269\u5C55\u5F39\u7A97\u91CC\u767B\u5F55", "err");
      return;
    }
    if (!selected.size) return;
    const idxs = Array.from(selected).sort((a, b) => a - b);
    const text = idxs.map((i) => cues[i]?.text || "").join(" ").replace(/\s+/g, " ").trim();
    const startTime = cues[idxs[0]]?.start ?? 0;
    setStatus("\u6536\u85CF\u4E2D...", "info");
    try {
      await postVocab(text, startTime);
      setStatus(`\u5DF2\u6536\u85CF\u5408\u5E76\u7684 ${idxs.length} \u53E5 \u2713`, "ok");
      clearSelection();
    } catch (err) {
      setStatus(err.message || "\u6536\u85CF\u5931\u8D25", "err");
    }
  }
  function hideSelBtn() {
    if (selBtn) selBtn.style.display = "none";
  }
  function onTextSelected() {
    if (!selBtn || !panel) return;
    const sel = window.getSelection();
    const text = (sel?.toString() || "").replace(/\s+/g, " ").trim();
    if (!text || !sel || sel.rangeCount === 0) {
      hideSelBtn();
      return;
    }
    let node = sel.anchorNode;
    let rowEl = null;
    while (node && node !== listEl) {
      if (node instanceof HTMLElement && node.classList?.contains("ytlingo-cue")) {
        rowEl = node;
        break;
      }
      node = node.parentNode;
    }
    const idx = rowEl ? Number(rowEl.dataset.index) : -1;
    const startTime = idx >= 0 && cues[idx] ? cues[idx].start : getVideoEl()?.currentTime || 0;
    const range = sel.getRangeAt(0).getBoundingClientRect();
    const panelRect = panel.getBoundingClientRect();
    selBtn.textContent = `\u2605 \u6536\u85CF\u6240\u9009\uFF1A${text.length > 18 ? text.slice(0, 18) + "\u2026" : text}`;
    selBtn.style.display = "block";
    selBtn.style.top = `${range.bottom - panelRect.top + 6}px`;
    selBtn.style.left = `${Math.max(8, Math.min(range.left - panelRect.left, panelRect.width - 160))}px`;
    selBtn.onclick = async (e) => {
      e.stopPropagation();
      if (!settings.token) {
        setStatus("\u8BF7\u5148\u5728\u6269\u5C55\u5F39\u7A97\u91CC\u767B\u5F55", "err");
        return;
      }
      hideSelBtn();
      setStatus("\u6536\u85CF\u4E2D...", "info");
      try {
        await postVocab(text, startTime);
        setStatus(`\u5DF2\u6536\u85CF\u7247\u6BB5\u300C${text.length > 20 ? text.slice(0, 20) + "\u2026" : text}\u300D\u2713`, "ok");
        window.getSelection()?.removeAllRanges();
      } catch (err) {
        setStatus(err.message || "\u6536\u85CF\u5931\u8D25", "err");
      }
    };
  }
  document.addEventListener("mousedown", (e) => {
    if (selBtn && e.target !== selBtn) hideSelBtn();
  });
  function startSync() {
    stopSync();
    syncTimer = window.setInterval(() => {
      const v = getVideoEl();
      if (!v || !cues.length || !listEl) return;
      const t = v.currentTime;
      let idx = -1;
      for (let i = 0; i < cues.length; i++) {
        if (t >= cues[i].start && t < cues[i].end) {
          idx = i;
          break;
        }
        if (cues[i].start > t) break;
      }
      if (idx !== activeIndex) {
        const prev = listEl.querySelector(".ytlingo-active");
        if (prev) prev.classList.remove("ytlingo-active");
        if (idx >= 0) {
          const node = listEl.querySelector(`[data-index="${idx}"]`);
          if (node) {
            node.classList.add("ytlingo-active");
            node.scrollIntoView({ block: "center", behavior: "smooth" });
          }
        }
        activeIndex = idx;
      }
    }, 300);
  }
  function stopSync() {
    if (syncTimer) {
      clearInterval(syncTimer);
      syncTimer = null;
    }
  }
  var captionObserver = null;
  var observerAttachTimer = null;
  var lastCaptured = "";
  function stopLiveCapture() {
    if (captionObserver) {
      captionObserver.disconnect();
      captionObserver = null;
    }
    if (observerAttachTimer) {
      clearInterval(observerAttachTimer);
      observerAttachTimer = null;
    }
  }
  function readRenderedCaption() {
    const segs = document.querySelectorAll(".ytp-caption-segment");
    return Array.from(segs).map((s) => s.textContent || "").join(" ").replace(/\s+/g, " ").trim();
  }
  function captureTick() {
    const text = readRenderedCaption();
    if (!text || text === lastCaptured) return;
    if (lastCaptured && (text.startsWith(lastCaptured) || lastCaptured.startsWith(text))) {
      if (cues.length) {
        cues[cues.length - 1].text = text;
        const lastRow = listEl?.lastElementChild?.querySelector(".ytlingo-cue-text");
        if (lastRow) lastRow.textContent = text;
        lastCaptured = text;
        return;
      }
    }
    lastCaptured = text;
    const v = getVideoEl();
    const start = v ? v.currentTime : 0;
    if (cues.length) cues[cues.length - 1].end = start;
    const cue = { start, end: start + 5, text };
    cues.push(cue);
    if (listEl) {
      listEl.appendChild(makeCueRow(cue, cues.length - 1));
      listEl.scrollTop = listEl.scrollHeight;
    }
  }
  function startLiveCapture() {
    ensurePanel();
    stopSync();
    stopLiveCapture();
    cues = [];
    lastCaptured = "";
    selected.clear();
    updateToolbar();
    if (listEl) listEl.innerHTML = "";
    setStatus("\u5B9E\u65F6\u6A21\u5F0F\uFF1A\u64AD\u653E\u89C6\u9891\uFF0C\u5B57\u5E55\u4F1A\u9010\u53E5\u51FA\u73B0\u5728\u8FD9\u91CC \u25B6", "ok");
    const attach = () => {
      const container = document.querySelector(".ytp-caption-window-container") || document.querySelector("#movie_player");
      if (!container) return false;
      captionObserver = new MutationObserver(() => captureTick());
      captionObserver.observe(container, { childList: true, subtree: true, characterData: true });
      return true;
    };
    if (!attach()) {
      observerAttachTimer = window.setInterval(() => {
        if (attach()) {
          clearInterval(observerAttachTimer);
          observerAttachTimer = null;
        }
      }, 700);
    }
  }
  function loadCuesDirect(newCues) {
    ensurePanel();
    stopLiveCapture();
    cues = newCues;
    activeIndex = -1;
    selected.clear();
    renderCues();
    updateToolbar();
    if (!cues.length) {
      setStatus("Caption track is empty for this video.", "err");
      return;
    }
    if (!settings.token) {
      setStatus(`${cues.length} lines \xB7 log in via the popup to save`, "info");
    } else {
      setStatus(`${cues.length} lines \xB7 saving to ${settings.targetLang}`, "ok");
    }
    startSync();
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== "ytlingo-inject") return;
    if (data.type === "CUES") {
      if (data.videoId && data.videoId !== currentVideoId) {
        currentVideoId = data.videoId;
        currentTitle = data.title || "";
        loadCuesDirect(data.cues || []);
      }
    } else if (data.type === "LIVE") {
      if (data.videoId && data.videoId !== currentVideoId) {
        currentVideoId = data.videoId;
        currentTitle = data.title || "";
        startLiveCapture();
      }
    } else if (data.type === "NO_CAPTIONS") {
      currentVideoId = data.videoId;
      currentTitle = data.title || "";
      ensurePanel();
      stopLiveCapture();
      setStatus("This video has no captions/subtitles.", "err");
    }
  });
  function isWatchPage() {
    return location.pathname === "/watch" && new URLSearchParams(location.search).has("v");
  }
  var lastUrl = "";
  function onLocationMaybeChanged() {
    if (location.href === lastUrl) return;
    lastUrl = location.href;
    if (isWatchPage()) {
      ensurePanel();
      setStatus("Detecting captions...");
      requestScan();
    } else {
      if (panel) {
        panel.remove();
        panel = null;
        listEl = null;
        statusEl = null;
      }
      currentVideoId = null;
      stopSync();
      stopLiveCapture();
    }
  }
  async function boot() {
    settings = await getSettings();
    onSettingsChanged((s) => {
      settings = s;
    });
    injectPageScript();
    window.addEventListener("yt-navigate-finish", () => setTimeout(onLocationMaybeChanged, 200));
    setInterval(onLocationMaybeChanged, 1e3);
    onLocationMaybeChanged();
  }
  void boot();
})();
